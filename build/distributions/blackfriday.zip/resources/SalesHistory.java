package com.indev.blackfriday;

public interface SalesHistory {

    void sales(int sellPackage);

    String getHistory();

}
